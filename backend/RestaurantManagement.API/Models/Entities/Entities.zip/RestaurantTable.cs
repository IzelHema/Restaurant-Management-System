﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.API.Models.Entities
{
    public class RestaurantTable
    {
        [Key]
        public int TableId { get; set; }

        [Required]
        public int TableNumber { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Available";

        public int Capacity { get; set; }

    }
}